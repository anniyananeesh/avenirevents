<?php

	function get_all_languages(){
		$languages = array(
			'en' => 'english',
			'ar' => 'arabic',
         	'rus' => 'russian'
		);
		return $languages;
	}
	
?>