<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Model_reviews extends MY_Model{
        protected $table_name = TBL_REVIEWS;
    }
