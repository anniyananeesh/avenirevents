<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_entertainers_management extends MY_Model{

	protected $table_name = TBL_ENTERTAINER;

}
