<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_promoter_management extends MY_Model{

	protected $table_name = TBL_COMPANY;

}
