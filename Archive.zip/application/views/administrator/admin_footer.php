<div id="footer">
	<div class="footer_line">&nbsp;</div>
	<div>&copy; Copyrights <? echo date('Y'); ?> <?=SITE_NAME?>. All rights reserved.</div>
</div>
</div>
</body>
</html>