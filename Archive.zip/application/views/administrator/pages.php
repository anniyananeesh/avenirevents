<div class="page-content">
    
    <div class="left-nav">
       <?php include("nav.php");?>
    </div>

    <div class="right-content">
        <?php include($page.".php");?>
    </div>
    
</div>