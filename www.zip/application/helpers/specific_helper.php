<?php
/*
|
| This file contains Project Specific Functions
|
|--------------------------------------------------------------------------
| This function return POPUP attributes
|--------------------------------------------------------------------------
*/		
		function get_popup_attributes(){
			$attributes = array(
              'width'      => '800',
              'height'     => '600',
              'scrollbars' => 'yes',
              'status'     => 'yes',
              'resizable'  => 'yes',
              'screenx'    => '100',
              'screeny'    => '100',
			  'title'	  => 'Title Here'
            );
			return $attributes;
		}
		
		
		

?>