<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Model_subscribers extends MY_Model{
		protected $table_name = TBL_SUBSCRIBERS;
/*
|--------------------------------------------------------------------------
| This function Returns
|--------------------------------------------------------------------------
*/


	}//class