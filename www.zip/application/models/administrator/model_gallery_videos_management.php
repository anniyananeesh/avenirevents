<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Model_gallery_videos_management extends MY_Model{
		
		protected $table_name = TBL_GALLERY_VIDEOS;
/*
|--------------------------------------------------------------------------
| This function Returns all the records
|--------------------------------------------------------------------------
*/
		public function example(){
			/*$this->db->select('*');
			$this->db->from($this->table_name);
			if (isset($param_array)){
				$this->db->where($param_array);
			}
			$this->db->limit($limit, $offset);
			$this->db->order_by($sort, $by);
			$query = $this->db->get();
			//print($this->db->last_query());
			return $query->result();*/
		}


	
		
				
	}//class