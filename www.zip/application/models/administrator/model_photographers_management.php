<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_photographers_management extends MY_Model{

	protected $table_name = TBL_PHOTOGRAPHER;

}
