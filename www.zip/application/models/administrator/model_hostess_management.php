<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_hostess_management extends MY_Model{

	protected $table_name = TBL_HOSTESS;

}
