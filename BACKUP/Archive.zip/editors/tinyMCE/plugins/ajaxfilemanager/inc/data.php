<pre>Array
(
    [currentFolderPath] => D:/xampp/htdocs/mountain_gate/images/uploads/
    [new_folder] => Icons
)
</pre>

18/Dec/2011 10:45:25