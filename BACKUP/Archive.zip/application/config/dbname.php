<?php
	define("DBASE_MAIN", "avenir_db");
?>