<?
	$config['next_link'] = "Next";
	
	$config['next_tag_open'] = '<span style="color:#FFFFFF; border:solid 1px #99022F; padding:5px; background-color:#EEE; margin-right:3px;font-family:arial">';
	$config['next_tag_close'] = '</span>';
	
	
	$config['prev_link'] = 'Previous';
	$config['prev_tag_open'] = '<span style="color:#FFFFFF; border:solid 1px #99022F; padding:5px; background-color:#EEE; margin-right:3px;font-family:arial ">';
	$config['prev_tag_close'] = '</span>';
	
	
	
	$config['first_link'] = 'First';
	$config['first_tag_open'] = '<span style="color:#FFFFFF; border:solid 1px #99022F; padding:5px; background-color:#EEE; margin-right:3px;font-family:arial ">';
	$config['first_tag_close'] = '</span>';
	
	$config['last_link'] = 'Last';
	$config['last_tag_open'] = '<span style="color:#FFFFFF; border:solid 1px #99022F; padding:5px; background-color:#EEE; margin-right:3px;font-family:arial ">';
	$config['last_tag_close'] = '</span>';
	
	
	$config['cur_tag_open'] = '<span style="border:solid 1px #99022F; padding:5px; line-height:35px; margin-bottom:10px; margin-top:10px text-decoration:none; margin-right:3px;color:#FFF;font-family:arial; background-color:#99022F;">';
	$config['cur_tag_close'] = '</span>';
	
	
	
	$config['num_tag_open'] = '<span style="border:solid 1px #99022F; padding:5px; background-color:#EEE; margin-right:3px;font-family:arial">';
	$config['num_tag_close'] = '</span>';
?>