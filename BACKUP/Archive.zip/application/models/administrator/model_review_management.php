<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Model_review_management extends MY_Model{
        protected $table_name = TBL_REVIEWS;
    }
