<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Model_language_management extends MY_Model{
	
	protected $table_name = TBL_LANGUAGE;

}