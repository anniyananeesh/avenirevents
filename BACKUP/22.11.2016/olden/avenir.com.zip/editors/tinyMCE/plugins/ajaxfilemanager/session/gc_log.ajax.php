<?php die(); ?>
gc start at 15/Feb/2015 06:25:22
